from django.apps import AppConfig


class IndustryConfig(AppConfig):
    name = 'industry'
