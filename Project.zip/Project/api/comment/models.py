from django.db import models
from api.user.supplier.models import Supplier
# Create your models here.

class Comment(models.Model):
	supplierId = models.OneToOneField(Supplier,on_delete=models.CASCADE,null=True, blank=True)
	CAC = models.TextField(max_length=250,null=True, blank=True)
	doc1 = models.TextField(max_length=250,null=True, blank=True)
	doc2 = models.TextField(max_length=250,null=True, blank=True)
	created_at = models.DateTimeField(auto_now_add=True, null=True, blank=True)
	updated_at = models.DateTimeField(auto_now=True)

	def __str__(self):
		return self.name
