from django.db import migrations
from api.user.models import User


class Migration(migrations.Migration):
    def seed_data(apps, schema_editor):
        user = User(name="Gideon",
        email = "sodipogideonolawale@gmail.com",
        is_staff=True,
        is_superuser=True,
        #phone="08108513978",
        #gender="Male"
               )

        user.set_password("swagger10net")
        user.save()

    dependencies = [

    ]


    operations = [
        migrations.RunPython(seed_data),
    ]
