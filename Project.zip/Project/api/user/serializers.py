from rest_framework import serializers
from .models import Supplier
from django.contrib.auth.hashers import make_password
from rest_framework.decorators import authentication_classes

class UserSerializer(serializers.HyperlinkedModelSerializer):
    url = serializers.HyperlinkedIdentityField(view_name=":user-detail")
    def create(self, validated_data):
        password = validated_data.pop('password', None)
        instance = self.Meta.model(**validated_data)

        if password is not None:
            instance.set_password(password)
        instance.save()
        return instance

    def updated(self, instance, validated_data):
        for attr, value in validated_data.items():
            if attr == 'password':
                instance.set_password(value)
            else:
                setattr(instance, attr, value)

        instance.save()
        return instance


    class Meta:
        model = Supplier
        extra_kwargs = {'password': {'write_only': True}}
        fields = '__all__'

        # fields = ('companyName','email', 'registrationNumber', 'phoneNumber',
        #           'contactName','contactPhone', 'contactJobTitle','contactDept','companyWeb', 'country',
        #           'state', 'city','postalZip','streetAddress','status','CAC', 'doc1', 'doc2',
        #           'industry', 'products', 'procurementManager', 'is_active', 'is_staff', 'is_superuser')

