from django.db import models
from api.industry.models import Industry
from django.contrib.auth.models import AbstractUser
from api.product_class.models import ProductClass
from api.product.models import Product
from django.conf import settings


class User(AbstractUser):
    username = None
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = []
    is_procurementManager = models.BooleanField(default=False)
    is_Supplier = models.BooleanField(default=False)
    name = models.CharField(max_length=50, default='Anonymous')
    session_token = models.CharField(max_length=10, blank=True, null=True)
    email = models.EmailField(max_length=200, unique=True)
    phoneNumber = models.CharField(max_length=100, null=True, blank=True)



class ProcurementManager(models.Model):
    procurementManager = models.OneToOneField(User, on_delete=models.CASCADE, primary_key=True)
    name = models.CharField(max_length = 100,null=True, blank=True)
    email = models.CharField(max_length = 200,null=True, blank=True)
    password = models.CharField(max_length = 100,null=True, blank=True)
    phoneNumber = models.CharField(max_length = 100,null=True, blank=True)
    contactPerson = models.CharField(max_length = 100,null=True, blank=True)
    country = models.CharField(max_length = 100,null=True, blank=True)
    state = models.CharField(max_length = 100,null=True, blank=True)
    city = models.CharField(max_length = 100,null=True, blank=True)
    address = models.CharField(max_length = 200,null=True, blank=True)
    postalZip = models.CharField(max_length = 300,null=True, blank=True)
    supplierId = models.CharField(max_length = 300,null=True, blank=True)


    def __str__(self):
        return self.name

class Supplier(models.Model):
    STATUS = (
        ('0', 'Rejected'),
        ('1', 'Approved'),
        ('2', 'Pending')
    )




    supplier = models.OneToOneField(User, on_delete=models.CASCADE, primary_key=True)
    companyName = models.CharField(max_length=200, default = 'Anonymous')
    industry = models.ForeignKey(Industry,on_delete=models.CASCADE, null=True, blank=True)
    #password = models.CharField(max_length = 200,null=True, blank=True)
    registrationNumber = models.CharField(max_length = 15,null=True, blank=True)
    contactName = models.CharField(max_length = 300,null=True, blank=True)
    contactPhone = models.CharField(max_length = 30,null=True, blank=True)
    contactJobTitle = models.CharField(max_length = 300,null=True, blank=True)
    contactDept = models.CharField(max_length = 300,null=True, blank=True)
    companyWeb = models.CharField(max_length = 100,null=True, blank=True)
    #dateTimeApproved = models.DateTimeField()
    country = models.CharField(max_length = 50,null=True, blank=True)
    state = models.CharField(max_length = 50,null=True, blank=True)
    city = models.CharField(max_length = 50,null=True, blank=True)
    postalZip = models.CharField(max_length = 20,null=True, blank=True)
    streetAddress = models.CharField(max_length = 300,null=True, blank=True)
    status = models.CharField(max_length=2, choices = STATUS,null=True, blank=True)
    products = models.ForeignKey(Product,null=True, blank=True, on_delete=models.CASCADE)
    CAC = models.FileField(upload_to='media',null=True, blank=True)
    doc1 = models.FileField(upload_to='media',null=True, blank=True)
    doc2 = models.FileField(upload_to='media',null=True, blank=True)
    procurementManager = models.ForeignKey(ProcurementManager,null=True, blank=True,on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    updated_at = models.DateTimeField(auto_now=True)


    def __str__(self):
        return self.name

