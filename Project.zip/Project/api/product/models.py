from django.db import models
from api.product_class.models import ProductClass

# Create your models here.

class Product(models.Model):
	classId = models.ForeignKey(ProductClass, on_delete=models.CASCADE,null=True, blank=True)
	productName = models.CharField(max_length = 200)
	created_at = models.DateTimeField(auto_now_add=True, null=True, blank=True)
	updated_at = models.DateTimeField(auto_now=True)

	def __str__(self):
		return self.name