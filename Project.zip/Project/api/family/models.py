from django.db import models
from api.segment.models import Segment

# Create your models here.
class Family(models.Model):
	segmentId = models.ForeignKey(Segment, on_delete=models.CASCADE,null=True, blank=True)
	familyName = models.CharField(max_length = 200,null=True, blank=True)
	created_at = models.DateTimeField(auto_now_add=True, null=True, blank=True)
	updated_at = models.DateTimeField(auto_now=True)

	def __str__(self):
		return self.name
