from django.apps import AppConfig


class FamilyConfig(AppConfig):
    name = 'family'
