from django.contrib import admin
from .models import ProductClass
# Register your models here.

admin.site.register(ProductClass)
