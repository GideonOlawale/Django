from django.apps import AppConfig


class ProductClassConfig(AppConfig):
    name = 'product_class'
