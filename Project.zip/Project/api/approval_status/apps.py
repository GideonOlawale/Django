from django.apps import AppConfig


class ApprovalStatusConfig(AppConfig):
    name = 'approval_status'
