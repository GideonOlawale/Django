from django.db import models
from api.user.supplier.models import Supplier

# Create your models here.

class ApprovalStatus(models.Model):
    STATUS = (('0', 'Approved'),('1', 'Pending'), ('2', 'Rejected'))
    supplierId = models.OneToOneField(Supplier,on_delete=models.CASCADE)
    CAC = models.CharField(max_length=2, choices = STATUS)
    doc1 = models.CharField(max_length=2, choices = STATUS)
    doc2 = models.CharField(max_length=2, choices = STATUS)
