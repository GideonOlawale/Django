from django.apps import AppConfig


class SegmentConfig(AppConfig):
    name = 'segment'
